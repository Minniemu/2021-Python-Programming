lootSystem.py			未完成
teamSub/teamAssembleSystem.py	未完成
teamSub/gridSystem.py		未完成
battleSystem.py			未完成

其餘事項：